
import os
import subprocess
import datetime

def banner(message):
    print("\n" + "-" * 10 + " " + message + " " + "-" * 10)

def run_command(command):
    print(f"Running command: {command}")
    subprocess.run(command, shell=True)

current_time = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
wrkpth = "/path/to/working/directory"
prj_name = "your_project_name"

# Sample command for hakrawler
web_targets = os.path.join(wrkpth, f"{prj_name}-web_targets-{current_time}.list")
with open(web_targets, "r") as file:
    for web in file.readlines():
        web = web.strip()
        print(f"--------------------------Scanning {web}------------------------")
        hakrawler_command = f"hakrawler --url {web} -js -linkfinder -robots -subs -urls -usewayback -insecure -depth 10 -outdir {wrkpth}/PathEnum/{prj_name}-{web.replace('/', '_').replace(':', '_')}-Hakcrawler-{current_time}"
        run_command(hakrawler_command)

        gobuster_command = f"gobuster dir -t 10 -w /usr/share/seclists/Discovery/Web-Content/common.txt -o {wrkpth}/PathEnum/{prj_name}-{web.replace('/', '_').replace(':', '_')}-gobuster-{current_time} -k --wildcard -u {web}"
        run_command(gobuster_command)

# XSStrike
banner("Performing scan using XSStrike")
with open(web_targets, "r") as file:
    for web in file.readlines():
        web = web.strip()
        print(f"--------------------------Scanning {web}------------------------")
        xsstrike_command = f"python3 /opt/XSStrike/xsstrike.py -u {web} --crawl -t 10 -l 10"
        run_command(xsstrike_command)

# Additional tools and commands would follow a similar pattern...

banner("WE ARE FINISHED!!!")
